L = 0.23e-3; %[H]
cm = 23.4e-3; %[Nm/A]
R = 2.4; %[Ohm]
J = 0.23e-6; %[Nm^2]
D = 0.4191e-5; %[N*sec/m]
out1=sim('ex6modelr.slx');
figure;

plot(out1.sx.time, out1.sx.signals(1).values) % Signal 1
hold on
plot(out1.sx.time, out1.sx.signals(2).values) % Signal 2
legend('Current','Speed')

grid on;